# AI Guide SDK

The **AI Guide SDK** is a revolutionary, incredibly easy-to-use toolkit that instantly adds an AI-powered visual guide to ANY web application. 

Instead of writing step-by-step tutorials, your users can simply ask the AI: *"How do I view my orders?"* and the AI will **literally take over the screen**, navigate through the application, and highlight the exact buttons and input fields the user needs to click.

**The best part?** The core runtime is built using pure Vanilla JavaScript DOM APIs, meaning it is **100% Framework Agnostic**. It works flawlessly whether you use Next.js, React, Vue, Svelte, Angular, or plain HTML.

---

## ⚡ Quick Start: Zero to AI in 3 Steps

If you want an AI to read this file and implement it for you, tell them: **"Read the README.md and follow the 3 Integration Steps to add the AI Guide SDK."**

### Step 1: Install the Package
Run this command in your project directory:
```bash
npm install ai-guide-sdk
```

### Step 2: Generate the `ai-blueprint.json`
The SDK needs to map out all the routes and interactive elements in your codebase so the AI knows where everything is. We have provided automated scanners for this:

**Option A: If you use Vite (React, Vue, Svelte)**
Add the `aiGuidePlugin` to your `vite.config.ts` (or `.js`). It will automatically scan your project and generate the blueprint into your `public/` folder every time you start the dev server.
```typescript
// vite.config.ts
import { defineConfig } from 'vite';
import { aiGuidePlugin } from 'ai-guide-sdk/vite-plugin';

export default defineConfig({
  plugins: [
    aiGuidePlugin() // <-- Add this!
  ]
});
```

**Option B: If you use anything else (Next.js, Angular, Webpack, Create React App)**
You don't need a plugin! Just run our Universal CLI command in your terminal. It will instantly scan your `src/`, `app/`, or `pages/` folders and drop the `ai-blueprint.json` right into your `public/` folder.
```bash
npx ai-guide-scan
```
*(Tip: Add `"ai-scan": "npx ai-guide-scan"` to your `package.json` scripts!)*

### Step 3: Initialize the SDK
Finally, initialize the SDK at the highest level of your application (like `main.js`, `App.tsx`, or `app/layout.tsx` for Next.js). 

```javascript
import { initGuideAI } from 'ai-guide-sdk';

// Call this once when your app mounts
initGuideAI({ 
  apiKey: 'sk-your-openai-api-key' // Replace with your real OpenAI Key!
});
```
*Note for Next.js Users: `initGuideAI` manipulates the DOM (`document` and `window`), so make sure you only run this on the Client side (inside a `useEffect` or checking `typeof window !== 'undefined'`).*

---

## 🎨 Perfecting the AI Guidance

The SDK is incredibly smart and can guess which buttons to highlight based on their text (e.g., `<button>Save</button>`). 

However, for **100% flawless accuracy**, we highly recommend adding explicit `id` attributes to the elements you want the AI to interact with.

```html
<!-- Good: The AI might guess this based on the text -->
<button>Go to Dashboard</button>

<!-- PERFECT: The AI will never miss this -->
<button id="btn_go_dashboard">Go to Dashboard</button>

<!-- PERFECT: Works flawlessly on inputs too -->
<input id="input_product_name" placeholder="Enter Product" />
```

If the SDK ever fails to highlight an element, it is almost always because the element does not have a clear, unique `id`.

## ⚙️ Configuration Options
When calling `initGuideAI()`, you can pass an optional configuration object:
```javascript
initGuideAI({
  apiKey: 'sk-...',
  model: 'gpt-4o',              // Optional: Defaults to gpt-4o
  theme: 'dark',                // Optional: 'light' | 'dark' | 'auto'
  position: 'right',            // Optional: 'left' | 'right'
  blueprintPath: '/ai-blueprint.json' // Path to your generated map
});
```

Enjoy your brand new AI copilot!
